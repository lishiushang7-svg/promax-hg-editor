Promax 心金 ROM Editor
本版直接解析 NDS Header、FNT、FAT，列出 ROM 內部檔案，並可對檔案內容做原位 Hex 修改；NARC 檔案會辨識 BTAF 等區塊並列出內部檔案範圍。

使用：
1. 開啟 index.html。
2. 選擇自己的 promax.nds。
3. 點選 ROM 內部檔案。
4. 使用 NARC 內部檔案查看或 Hex 修改。
5. 匯出 -edited.nds。

限制：
- 目前不自動修改 FAT/FNT，因此寫入內容不能超過原檔案大小。
- 這是基於實際 NDS 檔案系統的編輯器，不代表已完成所有 HGSS 遊戲資料格式解析。
- 建議先保留原始 ROM 備份。
